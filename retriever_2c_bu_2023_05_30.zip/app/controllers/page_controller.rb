class PageController < ApplicationController
	def pricing
	end

	def about
	end

end
